//
//  Post.swift
//  lab10
//
//  2023-03-26.
//

import Foundation

struct Post: Codable{
    let userId: Int
    let id: Int
    let title: String
    let body: String
}
